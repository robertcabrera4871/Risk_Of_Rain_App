package com.example.ror2companion

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import android.os.Bundle
import android.text.Layout
import android.text.SpannableString
import android.text.style.AlignmentSpan
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import kotlinx.android.synthetic.main.run_stats.*
import org.w3c.dom.Text

private lateinit var backgroundAnimation: AnimationDrawable

var theRun = Run("Commando",  ArrayList<Item>())
class RunStats: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            this.supportActionBar!!.hide()
        } catch (e: NullPointerException) {
        }
        setContentView(R.layout.run_stats)
        val theLayout: View = findViewById(R.id.runStatsLayout)
        theLayout.apply { setBackgroundResource(R.drawable.animation)
            backgroundAnimation = background as AnimationDrawable

        }
        if(intent.hasExtra("RunObject")) {
            theRun = intent.getSerializableExtra("RunObject") as Run
        }
        runCharImage.setImageResource(theRun.imgId)
        runStatsTextView.text = theRun.outputData()
    }
    override fun onStart() {
        super.onStart()
        backgroundAnimation.start()
    }
    fun toCharacterSelect(view: View) {
        val myIntent= Intent(this, MainActivity::class.java)
        startActivity(myIntent)
    }
    fun editDateAndLevel(view: View){
        val inflater: LayoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
         val popupWindow = PopupWindow(650, LinearLayout.LayoutParams.WRAP_CONTENT)
        val myView = inflater.inflate(R.layout.date_level_popup,null)
        val levelTextEdit = myView.findViewById<TextView>(R.id.LevelTextView)
        val dateTextView = myView.findViewById<TextView>(R.id.DateTextView)
        val levelDialog = levelDialogBuilder(levelTextEdit)
        val dateDialog = dateDialogBuilder(dateTextView)
        popupWindow.contentView = myView
         myView.findViewById<Button>(R.id.exitButton).setOnClickListener{
                popupWindow.dismiss()
        }
        myView.findViewById<Button>(R.id.finishEditButton).setOnClickListener{

        }
        levelTextEdit.setOnClickListener{
            levelDialog.show()
        }
        dateTextView.setOnClickListener{
            dateDialog.show()
        }
        popupWindow.showAtLocation(
            findViewById<ConstraintLayout>(R.id.runStatsLayout),
            Gravity.CENTER,
            0,
            0
        )
    }
    private fun levelDialogBuilder(myTextView: TextView): Dialog{
        val builder = AlertDialog.Builder(this)
        val title = SpannableString("Pick Your Level")
        title.setSpan(AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), 0, title.length, 0)
        builder.setTitle(title)
        val numberPicker = NumberPicker(this)
        numberPicker.minValue = 0
        numberPicker.maxValue = 100
        builder.setView(numberPicker)
        builder.setPositiveButton("Accept"){dialogInterface, which ->
           myTextView.text = numberPicker.value.toString()
        }
        builder.setNegativeButton("Cancel"){dialogInterface, which ->
        }
        return builder.create()
    }
    private fun dateDialogBuilder(myTextView: TextView): Dialog{
        val inflater: LayoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val myView = inflater.inflate(R.layout.custom_date_picker,null)
        val builder = AlertDialog.Builder(this)
        val title = SpannableString("Set Date of Run")
        title.setSpan(AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), 0, title.length, 0)
        builder.setTitle(title)
        builder.setView(myView)
        val datePicker = myView.findViewById<DatePicker>(R.id.runDatePicker)
        builder.setPositiveButton("Accept"){dialogInterface, which ->
                myTextView.text = "${datePicker.month + 1}/${datePicker.dayOfMonth}/${datePicker.year}"
    }
        builder.setNegativeButton("Cancel"){dialogInterface, which ->
        }
        val returnDialog = builder.create()
        return returnDialog
    }
}
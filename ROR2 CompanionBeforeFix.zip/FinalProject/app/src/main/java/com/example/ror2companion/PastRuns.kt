package com.example.ror2companion

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class PastRuns: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            this.supportActionBar!!.hide()
        } catch (e: NullPointerException) {
        }
        setContentView(R.layout.past_runs)
    }

    fun toCharacterSelect(view: View){
        finish()
    }
    fun toRunScreen(view: View){
        val myIntent= Intent(this, RunStats::class.java)
        startActivity(myIntent)
    }
}